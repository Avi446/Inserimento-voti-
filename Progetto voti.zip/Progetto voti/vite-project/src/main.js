import './style.css';

const votesList = document.getElementById("votesList");
const saveBtn = document.getElementById("saveVote");
const msg = document.getElementById("msg");

// FUNZIONE: colore in base al voto 
function getVoteColorClass(voto) {
  if (voto >= 6) return "voto-alto";        // verde
  if (voto >= 5) return "voto-medio";       // arancione
  return "voto-basso";                       // rosso
}

// FUNZIONE: emoji in base al voto 
function getVoteEmoji(voto) {
  if (voto >= 6) return "😃";
  if (voto >= 5) return "😐";
  return "😢";
}

// FUNZIONE MESSAGGI 
function showMessage(text, color = "green") {
  msg.textContent = text;
  msg.style.color = color;
  setTimeout(() => msg.textContent = "", 2500);
}

// DEBUG DEL SERVER 
function handleResponseStatus(res, bodyText) {
  console.log("HTTP", res.status, res.statusText);
  console.log("Body:", bodyText);
  if (!res.ok) {
    showMessage("Errore server: " + res.status, "red");
  }
}

// CARICA E MOSTRA VOTI 
async function loadVotes() {
  try {
    const res = await fetch("http://127.0.0.1:8090/api/collections/voti/records");
    const data = await res.json();

    votesList.innerHTML = "";

    if (!data || !data.items || data.items.length === 0) {
      votesList.innerHTML = "<li>Nessun voto presente</li>";
      return;
    }

    data.items.forEach(item => {
      const div = document.createElement("div");
      div.classList.add("voto-card", getVoteColorClass(item.voto));
      div.innerHTML = `
        <span>${item.nome ?? 'N/A'}</span>
        <strong>${item.voto ?? 'N/A'} ${getVoteEmoji(item.voto)}</strong>
      `;
      votesList.appendChild(div);
    });
  } catch (err) {
    console.error("Errore GET:", err);
    showMessage("Errore nel caricamento", "red");
  }
}

// SALVA IL VOTO 
saveBtn.onclick = async () => {
  const nome = document.getElementById("nome").value.trim();
  const voto = Number(document.getElementById("voto").value);

  if (!nome || isNaN(voto)) {
    showMessage("Inserisci nome e voto!", "red");
    return;
  }

  if (voto < 0 || voto > 10) {
    showMessage("Il voto deve essere tra 0 e 10", "red");
    return;
  }

  const payload = { nome, voto };
  console.log("Invio payload:", payload);

  try {
    const res = await fetch("http://127.0.0.1:8090/api/collections/voti/records", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(payload)
    });

    const text = await res.text();
    let parsed;
    try { parsed = JSON.parse(text); } catch(e) { parsed = text; }

    handleResponseStatus(res, parsed);

    if (res.ok) {
      showMessage("Voto salvato!");
      document.getElementById("nome").value = "";
      document.getElementById("voto").value = "";
      loadVotes();
    } else {
      console.error("Errore creazione:", parsed);
    }
  } catch (err) {
    console.error("Fetch POST fallito:", err);
    showMessage("Errore nella richiesta", "red");
  }
};

// CARICA SUBITO 
loadVotes();
